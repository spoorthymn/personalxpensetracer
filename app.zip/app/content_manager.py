def CategoriesText():
	CATS = {
	'Daily' : ['Food', 'Travel', 'Clothing', 'Entertainment', 'Online Shopping'],
	'Monthly' : ['Electricity Bill', 'Water Bill', 'Gas', 'Groceries']
	}
	return CATS
